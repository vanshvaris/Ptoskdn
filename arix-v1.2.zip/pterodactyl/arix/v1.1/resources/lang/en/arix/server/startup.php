<?php

return [
    'startup-settings' => 'Startup Settings',
    'startup-command' => 'Startup Command',
    'docker-image' => 'Docker Image',
    'read-only' => 'Read Only',
    'select-docker-feature' => 'This is an advanced feature allowing you to select a Docker image to use when running this server instance.',
    'custom-docker-image' => 'This {"server\'s"} Docker image has been manually set by an administrator and cannot be changed through this UI.',
    'variables' => 'Variables'
];